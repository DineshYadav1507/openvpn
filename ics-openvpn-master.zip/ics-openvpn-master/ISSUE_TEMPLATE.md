To make issues more manageable, I would appreciate it if you fill out the following details as applicable:

# General information
1. Android Version
2. Android Vendor/Custom ROM
3. Device
4. Version of the app (version number/play store version/self-built)
 
# Description of the issue

# Log (if applicable)

```
log contents
```

# Configuration file

```
add the contents of the configuration file if applicable
be careful to not post private keys
```

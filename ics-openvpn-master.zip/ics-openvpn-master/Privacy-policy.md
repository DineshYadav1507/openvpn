Privacy Policy for OpenVPN for Android
=====================================

The app OpenVPN for Android does not communicate to any server other than the
OpenVPN servers provided in configuration files. The author himself does not
collect any data and no therefore also no data is saved. For the privacy
policy for the OpenVPN server/VPN service you are using (or other services related to the project
like GitHub), please refer to their respective privacy policy.

End of service
==============
The program and its components are under open-source licenses that allow you to use this app forever 
according to terms of the open-source licenses for details.

However, the author reserves the right to suspend development or stop publishing the OpenVPN app or updates 
to it at any time.


